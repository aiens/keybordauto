
# 图标文件说明
请将以下图标文件放置在 assets/ 目录中：

macOS: icon.icns (512x512 像素的 .icns 文件)
Windows: icon.ico (256x256 像素的 .ico 文件)  
Linux: icon.png (256x256 像素的 .png 文件)

可以使用在线工具将 PNG 图片转换为对应格式：
- https://convertio.co/png-icns/ (PNG to ICNS)
- https://convertio.co/png-ico/ (PNG to ICO)
